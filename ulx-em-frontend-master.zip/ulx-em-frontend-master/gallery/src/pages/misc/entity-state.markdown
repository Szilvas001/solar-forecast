---
title: Entity State
---
