---
title: Describe Condition
---
