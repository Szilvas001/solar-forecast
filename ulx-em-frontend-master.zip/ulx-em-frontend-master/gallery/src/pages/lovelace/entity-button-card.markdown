---
title: Entity Button Card
---
